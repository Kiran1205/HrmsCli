import { Component } from '@angular/core';

@Component({
  selector: 'app-form16',
  standalone: true,
  imports: [],
  templateUrl: './form16.component.html',
  styleUrl: './form16.component.css'
})
export class Form16Component {

}
